Test Case 17 using Java Selenium WebDriver.Platform https://demo.prestashop.com/#/en/front.Steps
1 Navigate using driver.get().
2.Locate elements using By Locators
3.Interact using WebElement methods
4.Verify using TestNG assertions.
5.Use WebDriverWait for synchronization.
Expected Result:Test case 17 executes successfully with Selenium