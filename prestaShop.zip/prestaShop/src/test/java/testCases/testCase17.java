package testCases;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.time.Duration;

public class testCase17 {

    private WebDriver driver;
    private final String BASE_URL = "https://demo.prestashop.com/#/en/front"; 
    private final String SEARCH_TERM = "T-shirt"; 

    
    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test(priority = 1, description = "Verifies the search functionality on PrestaShop.")
    public void	productSearch() {
        
        System.out.println("Navigating to the URL");
        driver.get(BASE_URL);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        
        System.out.println("Waiting for and switching to the shop iframe...");
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("framelive")));
        
        By searchInputLocator = By.xpath("//input[@placeholder='Search our catalog']");
        By searchResultsLocator = By.cssSelector("div#js-product-list h2");

        WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(searchInputLocator));
        System.out.println("Search input located");

        System.out.println("Interacting with search field by typing " + SEARCH_TERM);
        searchInput.sendKeys(SEARCH_TERM);
        
        By searchButtonLocator = By.cssSelector("button[type='submit']");
        wait.until(ExpectedConditions.elementToBeClickable(searchButtonLocator)).click();

        WebElement searchResultsHeading = wait.until(
            ExpectedConditions.visibilityOfElementLocated(searchResultsLocator)
        );
        System.out.println("Search results loaded");


        // Verify using TestNG assertions
        String actualHeadingText = searchResultsHeading.getText();
        String expectedHeadingPartialText = "SEARCH RESULTS"; 

        System.out.println("Verifying the search results...");
        
        // Assertion
        Assert.assertTrue(
            actualHeadingText.contains(expectedHeadingPartialText),
            "Verification Failed: Search results heading does not contain '" + expectedHeadingPartialText + "'. Actual text: " + actualHeadingText
        );
        System.out.println("Test case 17 executes successfully with Selenium.");
    }

    @AfterClass
    public void close() {
        // Quit browser
        if (driver != null) {
            driver.quit();
        }
    }
}