package testCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.time.Duration;

public class testCase17 {

	WebDriver driver;
	WebDriverWait wait;
	WebElement searchBox;
	WebElement logo;

	@BeforeClass
	public void setup() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		System.out.println("opened browser succesfully");
	}

	@Test(priority = 1)
	public void navigate() { // navigate to website

		driver.get("https://demo.prestashop.com/#/en/front");
		System.out.println("Navigated to the website");
		WebElement frame = driver.findElement(By.tagName("iframe")); // swtich to iframe
		driver.switchTo().frame(frame);
		System.out.println("switched to frame");
	}

	@Test(priority = 2)
	public void locateElements() {

		searchBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.name("s")));
		System.out.println("located search box");

		logo = driver.findElement(By.cssSelector(".logo"));
		System.out.println("located logo");
	}

	@Test(priority = 3)
	public void InteractWithElements() { // Interacting with WebElement

		searchBox.sendKeys("shirt");
		System.out.println("Entered text shirt in searchBox)");

		boolean isSearchBoxDisplayed = searchBox.isDisplayed();
		System.out.println("check if search box is displayed: " + isSearchBoxDisplayed);
	}

	@Test(priority = 4)
	public void VerifywithAssertions() { // Verify using TestNG assertions

		Assert.assertTrue(searchBox.isDisplayed(), "Search box should be displayed");
		System.out.println("verified search box is displayed ");

		Assert.assertTrue(logo.isDisplayed(), "check Logo is displayed");
		System.out.println("verified logo is displayed");

	}

	@Test(priority = 5)
	public void usingWait() { // Using WebDriverWait for synchronization

		wait.until(ExpectedConditions.elementToBeClickable(searchBox));
		System.out.println("using WebDriverWait to verify search box is clickable");

		wait.until(ExpectedConditions.visibilityOf(logo));
		System.out.println("using WebDriverWait to verify logo is visible");

		String title = driver.getTitle();
		System.out.println("page title is: " + title);

		System.out.println("\nTest Case 17 executed successfully with Selenium");
	}

	@AfterClass
	public void close() { // close the browser
		driver.quit();
		System.out.println("Browser closed");
	}
}